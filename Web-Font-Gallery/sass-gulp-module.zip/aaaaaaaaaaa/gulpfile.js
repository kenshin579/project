'use strict'

// 환경 설정 옵션
var gulp = require('gulp');
var config = require('./gulp.config');

// gulp-if 모듈을 로드 : 조건에 따른 업무 처리
var g_if = require('gulp-if');

// ------------- BROWSER 동기화
// 서버 환경 구성
// 서버를 띄워 놓고 감시하는 파일을 수정하면 자동으로 브라우저를 리로드.
var  browserSync = require('browser-sync').create();

// ------------- CSS
// Sourcemaps 모듈을 로드 : 개발 시, Debug 용으로 사용할 소스맵을 생성.
var sourcemaps = require('gulp-sourcemaps');
// sass 모듈을 로드
var sass = require('gulp-sass');
// autoprefixer 모듈을 로드 
// CSS3 브라우저 벤더 프리픽스를 설정에 따라 자동으로 적용 처리.
var autoprefixer = require('gulp-autoprefixer');
// gulp-csscomb 모듈을 로드 : CSS 문서 포멧 정리 및 속성 별로 정렬
var csscomb = require('gulp-csscomb');

// ------------- JS
// gulp-concat : Javascript 파일 병합
var concat = require('gulp-concat');


//-------------------------------------------------------------------------

// gulp 기본 수행할 일(task) 등록
// 기본 문법 
// gulp.task('테스크네임', function(){ gulp.run('compile:css'); });
// gulp.task('default', [ 배열로 던져 등록된 순서대로 수행됨 ]);
gulp.task('default', [
    'server',
    'compile:html',
    'compile:css',
    'compile:js',
    'watch'
]);

// 관찰(Watch) 업무
gulp.task('watch', function() {
    // gulp.watch( 이곳이 변경이 생길때 마다, ['이 일을 수행해']);
    gulp.watch(config.paths.html.src, ['compile:html']);
    gulp.watch(config.paths.sass.src, ['compile:css']);
    gulp.watch(config.paths.js.src, ['compile:js']);
    // src폴더의 모든폴더의 모든파일이 변경될때 마다 브라우저 동기화
    gulp.watch(config.project.source + '**/**' ).on( 'change', browserSync.reload );
});

// 서버(Server) 동기화 업무
// gulp.task('server',['html','css',,배열은 감시할 파일들], function() { });
gulp.task('server', function() {
    browserSync.init( config.options.browserSync );
});

// Sass 업무 등록  : Sass → CSS 업무
gulp.task('compile:css', function() {
    return gulp.src(config.paths.sass.src)
               .pipe( g_if(config.paths.sass.sourcemaps.use, sourcemaps.init() ) )
               .pipe( sass( config.paths.sass.options ).on('error', sass.logError) )
               .pipe( autoprefixer([
                    'ie >= 8',
                    'ie_mob >= 10',
                    'ff >= 30',
                    'chrome >= 34',
                    'safari >= 7',
                    'opera >= 23',
                    'ios >= 7',
                    'android >= 4.4',
                    'bb >= 10'
                  ]) )
               .pipe( csscomb() )
               .pipe( g_if(config.paths.sass.sourcemaps.use, sourcemaps.write(config.paths.sass.sourcemaps.location) ) )
               .pipe( gulp.dest(config.paths.sass.dest) )
               .pipe( browserSync.stream() );
});

// js
gulp.task('compile:js', function() {
  return gulp.src( config.paths.js.src )
             .pipe( concat('all.js') )
             .pipe( gulp.dest( config.paths.js.dest ) );
});

// html
gulp.task('compile:html', function() {
  return gulp.src( config.paths.html.src )
             .pipe( gulp.dest( config.paths.html.dest ) );
});

